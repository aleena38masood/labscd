/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectscd;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Hp
 */
public class Pharmacy {
     LinkList L=new LinkList();
    
    public void Add_record(){
       Scanner input=new Scanner(System.in);
       System.out.println("Enter the ID of Medicine : ");
       int IDMed=input.nextInt();
       System.out.println("Enter medicine name : ");
       String nameMed=input.next();
       System.out.println("Enter Medicine Formula : ");
       String formulaMed=input.next();
       System.out.println("Enter Medicine Price");
       int priceMed=input.nextInt();
       System.out.println("Enter Medicine Type : ");
       String typeMed=input.next();
       System.out.println("Enter Medicine Manufacture date");
       int dateMed=input.nextInt();
       System.out.println("Enter Medicine Manufacture Month");
       int MonMed=input.nextInt();
       System.out.println("Enter Medicine Manufacture Year");
       int YearMed=input.nextInt();
       System.out.println("Enter Medicine Expire date");
       int ex_dateMed=input.nextInt();
       System.out.println("Enter Medicine Expire Month");
       int ex_monMed=input.nextInt();
       System.out.println("Enter Mecdicine Expire Year");
       int ex_yearMed=input.nextInt();
       
       L.push_back(IDMed, nameMed, formulaMed, priceMed, typeMed, dateMed,MonMed,YearMed, ex_dateMed, ex_monMed, ex_yearMed);
            {
        try {
            FileWriter fw=new FileWriter("E:\\Pharmacy Stock_2.text",true);
            
             fw.write(" " +IDMed+" "+nameMed+" "+formulaMed+" "+priceMed+" "+typeMed+" "+dateMed+" _"+MonMed+"_ "+YearMed+" _"+ ex_dateMed+"_ "+ ex_monMed+"_ "+ ex_yearMed+"\n");
             fw.close();
             
        } catch (IOException ex) {
            Logger.getLogger(Pharmacy.class.getName()).log(Level.SEVERE, null, ex);
        }
      }
    }
    
    public void update(){
        System.out.println("Enter ID to update the record");
        Scanner Sc=new Scanner(System.in);
        int Id=Sc.nextInt();
        L.search(Id);
        if(L.search(Id)==true){
       Scanner input=new Scanner(System.in);
       System.out.println("Enter the ID of Medicine : ");
       int ID=input.nextInt();
       System.out.println("Enter medicine name : ");
       String name=input.next();
       System.out.println("Enter Medicine Formula : ");
       String formula=input.next();
       System.out.println("Enter Medicine Price");
       int price=input.nextInt();
       System.out.println("Enter Medicine Type : ");
       String type=input.next();
       System.out.println("Enter Medicine Manufacture date");
       int date=input.nextInt();
       System.out.println("Enter Medicine Manufacture Month");
       int Mon=input.nextInt();
       System.out.println("Enter Medicine Manufacture Year");
       int Year=input.nextInt();
       System.out.println("Enter Medicine Expire date");
       int ex_date=input.nextInt();
       System.out.println("Enter Medicine Expire Month");
       int ex_mon=input.nextInt();
       System.out.println("Enter Mecdicine Expire Year");
       int ex_year=input.nextInt();
       
         try {
            FileWriter fw=new FileWriter("E:\\Pharmacy Stock_2.text",true);
            
             fw.write(" " +ID+" "+name+" "+formula+" "+price+" "+type+" "+date+" _"+Mon+"_ "+Year+" _"+ ex_date+"_ "+ ex_mon+"_ "+ ex_year+"\n");
             fw.close();
             
        } catch (IOException ex) {
            Logger.getLogger(Pharmacy.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        else{
            System.out.println("Item Not Found");
        }
                  
     
    }
    public void find(){
     System.out.println("Enter ID for search");
        Scanner S=new Scanner(System.in);
       int ID=S.nextInt();
        L.search(ID);
    }
    
    public void delete(){
         System.out.println("Enter record for ID");
        Scanner S=new Scanner(System.in);
        int ID=S.nextInt();
        L.del(ID);
    }
    public void print_Bill(){
     Node temp=L.head;
     int total=0;
    
     
     while(temp!=null){
         total=total+temp.price;
         temp=temp.next;
     }
     
       System.out.println(total); 
        
     
      //System.out.println("Not Available");
 } 
    
    public void Display_All(){
        Node temp;
        temp=L.head;
       while (temp!=null){
        temp.DisplayNode();
        temp=temp.next;
    }
    }
    
    public void countMed(){
        System.out.println("Enter name of medicine for count");
        Scanner S=new Scanner(System.in);
        String name=S.nextLine();
        L.countMed(name);
}
}

