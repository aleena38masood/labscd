/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newdatabase;

/**
 *
 * @author Hp
 * 
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;


import java.sql.*;
public class NewDatabase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
            

try{  
Class.forName("com.mysql.cj.jdbc.Driver");  
//here sonoo is database name, root is username and password
    try (Connection con = DriverManager.getConnection(  
            "jdbc:mysql://localhost:3306/task","root","")) {
        //here sonoo is database name, root is username and password
        Statement stmt=con.createStatement();
        stmt.executeUpdate("INSERT into login VALUES ('noor','7788')");
        ResultSet rs=stmt.executeQuery("select * from login");
        while(rs.next())
            System.out.println(rs.getString(1)+"  "+rs.getString(2));  
    }
}catch(Exception e){ System.out.println(e);}  


}
    }
    

